package com.safetygenie.alert.Activity;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.support.design.widget.BottomNavigationView;

import com.safetygenie.alert.Fragments.BusStopFragment;
import com.safetygenie.alert.Fragments.GenieFragment;
import com.safetygenie.alert.Fragments.JourneyFragment;
import com.safetygenie.alert.Fragments.ProfileFragment;
import com.safetygenie.alert.R;
import com.safetygenie.alert.Util.Util;

public class MainActivity extends AppCompatActivity {

    String accountID = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNavigationView = (BottomNavigationView)
                findViewById(R.id.navigation);

        bottomNavigationView.setOnNavigationItemSelectedListener
                (new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                        Fragment selectedFragment = null;
                        switch (item.getItemId()) {
                            case R.id.action_item1:
                                selectedFragment = JourneyFragment.newInstance();
                                break;
                            case R.id.action_item3:
                                selectedFragment = BusStopFragment.newInstance();
                                break;
                            case R.id.action_item4:
                                selectedFragment = ProfileFragment.newInstance();
                                break;
                        }
                        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.frame_layout, selectedFragment);
                        transaction.commit();
                        return true;
                    }
                });
        setupDetails();

        accountID = "1";
        if (accountID.isEmpty()){
            showWelcome();
        }
        else{
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.frame_layout, JourneyFragment.newInstance());
            transaction.commit();
        }
    }

    public void setupDetails(){
        accountID = Util.getAccountID (getApplicationContext());
    }

    public void showWelcome(){
        Intent intent = new Intent(this, WelcomeActivity.class);
        startActivity(intent);
    }
}
