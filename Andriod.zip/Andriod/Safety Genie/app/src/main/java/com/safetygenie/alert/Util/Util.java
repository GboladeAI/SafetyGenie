package com.safetygenie.alert.Util;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

public class Util {

    public static String getAccountID(Context context) {
        SharedPreferences preferences = context.getSharedPreferences("MyPreferences", Context.MODE_PRIVATE);
        String authData = preferences.getString("auth","");
        String account_id = "";
        try {
            JSONObject result = new JSONObject(authData).getJSONObject("user");
            account_id = result.getString("account_id");
            return account_id;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return account_id;
    }

    private static ProgressDialog progressDialog = null;

    public static void showNotification(Context context, String message ){
        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
    }

    public static void showProgressDialog(Context context,  int mylayout, String message)
    {
        progressDialog = new ProgressDialog(context ,  mylayout);
        progressDialog.setMessage(message);
        progressDialog.show();
    }

    public static void dismissProgressDialog()
    {
        progressDialog.dismiss();
    }
    public static void clearDialog()
    {
        progressDialog = null;
    }

}

