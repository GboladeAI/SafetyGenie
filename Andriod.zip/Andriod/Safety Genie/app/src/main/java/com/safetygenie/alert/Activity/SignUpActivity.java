package com.safetygenie.alert.Activity;

import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.safetygenie.alert.R;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;

import com.worklight.wlclient.api.WLFailResponse;
import com.worklight.wlclient.api.WLResourceRequest;
import com.worklight.wlclient.api.WLResponse;
import com.worklight.wlclient.api.WLResponseListener;

public class SignUpActivity extends AppCompatActivity {

    EditText firstNameText, lastNameText, emailText, phoneText, addressText, lgaText, stateText, passwordText, confirmPasswordText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        Button signupButton = (Button)findViewById(R.id.btn_signup);

        firstNameText = (EditText) findViewById(R.id.input_first_name);
        lastNameText = (EditText) findViewById(R.id.input_last_email);
        emailText = (EditText) findViewById(R.id.input_email);
        phoneText = (EditText) findViewById(R.id.input_phone);
        addressText = (EditText) findViewById(R.id.input_street);
        lgaText = (EditText) findViewById(R.id.input_lga);
        stateText = (EditText) findViewById(R.id.input_state);
        passwordText = (EditText) findViewById(R.id.input_password);
        confirmPasswordText = (EditText) findViewById(R.id.input_password_confirm);

        signupButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                URI adapterPath = null;

                try {
                    adapterPath = new URI("/adapters/Lamata_Adapter/createusers");

                    WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    WifiInfo wInfo = wifiManager.getConnectionInfo();
                    String macAddress = wInfo.getMacAddress();

                    WLResourceRequest request = new WLResourceRequest(adapterPath, WLResourceRequest.POST);
                    HashMap<String,String> formParams = new HashMap<>();
                    formParams.put("FIRSTNAME", firstNameText.getText().toString());
                    formParams.put("MIDDLENAME", "NIL");
                    formParams.put("SURNAME", lastNameText.getText().toString());
                    formParams.put("BIRTHDATE", "NIL");
                    formParams.put("STREET1", addressText.getText().toString());
                    formParams.put("STREET2", "NIL");
                    formParams.put("LGA", lgaText.getText().toString());
                    formParams.put("STATE", stateText.getText().toString());
                    formParams.put("MARITAL_STATUS", "NIL");
                    formParams.put("MOBILENUMBER", phoneText.getText().toString());
                    formParams.put("MACADDRESS", macAddress);
                    formParams.put("EMAILADDRESS", emailText.getText().toString());
                    formParams.put("PASSWORD", passwordText.getText().toString());
                    formParams.put("CONFIRMPASSWORD", confirmPasswordText.getText().toString());
                    formParams.put("APPID", "1");

                    request.send(formParams,new WLResponseListener() {
                        public void onSuccess(WLResponse response) {
                            String responseText = response.getResponseText();
                            System.out.println("RESPONSE::::::"+ responseText.toString());
                            String resultText = "";
                            resultText = responseText;
                            System.out.println("SUCCESSFULLL INSERT");
                            Log.d("InvokeSuccess", responseText);
                        }

                        public void onFailure(WLFailResponse response) {
                            String errorMsg = response.getErrorMsg() + ":::::::" + response.getErrorStatusCode()+":::::"+ response.getHeaders().toString() ;
                            Log.d("InvokeFail", errorMsg);
                        }
                    });

                } catch (URISyntaxException e) {
                    e.printStackTrace();
                }
                Intent startIntent = new Intent(SignUpActivity.this, VerifyActivity.class);
                startIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(startIntent);
            }
        });

    }
}
