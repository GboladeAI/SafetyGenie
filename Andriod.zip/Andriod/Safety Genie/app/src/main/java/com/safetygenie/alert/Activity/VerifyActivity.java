package com.safetygenie.alert.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.safetygenie.alert.R;

public class VerifyActivity extends AppCompatActivity {

    EditText verifyText;
    Button verifyButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify);

        verifyText = (EditText) findViewById(R.id.input_verify);
        verifyButton = (Button) findViewById(R.id.btn_verify);

        verifyButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent startIntent = new Intent(VerifyActivity.this, MainActivity.class);
                startIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(startIntent);
            }
        });
    }
}
