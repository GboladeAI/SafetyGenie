
package com.safetygenie.alert;

import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.AdaptersAPI;
import com.ibm.mfp.adapter.api.ConfigurationAPI;
import com.ibm.mfp.adapter.api.OAuthSecurity;

import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import java.sql.*;
import java.util.ArrayList;
import java.util.Properties;


@Path("/")
public class DisasterReportResource {
	/*
	 * For more info on JAX-RS see https://jax-rs-spec.java.net/nonav/2.0-rev-a/apidocs/index.html
	 */

	@Context
	ConfigurationAPI configurationAPI;

	@Context
	AdaptersAPI adaptersAPI;
/*
 * 
 <jdbc-connection-pool allow-non-component-callers="false" associate-with-thread="false" connection-creation-retry-attempts="0" connection-creation-retry-interval-in-seconds="10" connection-leak-reclaim="false" connection-leak-timeout-in-seconds="0" connection-validation-method="auto-commit" datasource-classname="com.ibm.db2.jcc.DB2DataSource" fail-all-connections="false" idle-timeout-in-seconds="300" is-connection-validation-required="false" is-isolation-level-guaranteed="true" lazy-connection-association="false" lazy-connection-enlistment="false" match-connections="false" max-connection-usage-count="0" max-pool-size="32" max-wait-time-in-millis="60000" name="db2_BLUDB_dash017728Pool" non-transactional-connections="false" pool-resize-quantity="2" res-type="javax.sql.DataSource" statement-timeout-in-seconds="-1" steady-pool-size="8" validate-atmost-once-period-in-seconds="0" wrap-jdbc-objects="false">
        <property name="serverName" value="bluemix05.bluforcloud.com"/>
        <property name="portNumber" value="50000"/>
        <property name="databaseName" value="BLUDB"/>
        <property name="User" value="dash017728"/>
        <property name="Password" value="2gwXRe7rWdtV"/>
        <property name="URL" value="jdbc:db2://bluemix05.bluforcloud.com:50000/BLUDB"/>
        <property name="driverClass" value="com.ibm.db2.jcc.DB2Driver"/>
    </jdbc-connection-pool> 
 * 
 */
	  public Connection getConnection() {

	        Connection conn=null;

	        Properties props = new Properties();
	 	   try{
	 	        String strUrl = "jdbc:db2://bluemix05.bluforcloud.com:50000/BLUDB";
	 	   props.put("user", "dash017728");
	 	   props.put("password","2gwXRe7rWdtV");
	 	       try{
	 	    System.out.println("****ABOUT to make DB2 BLU CONNECTION SUCCESSFUL****");
	 	    Class.forName("com.ibm.db2.jcc.DB2Driver");
	 	conn = DriverManager.getConnection(strUrl, props); 
	 	conn.setTransactionIsolation( Connection.TRANSACTION_READ_UNCOMMITTED );
	 	System.out.println("****DB2 BLU CONNECTION SUCCESSFUL****");
	 	       }catch(Exception ex){
	 	           System.out.println("ERROR in Driver:"+ ex.getMessage());
	 	           ex.printStackTrace();
	 	       }

	 	   }catch(Exception ex){System.out.println("ERROR in Driver:"+ ex.getMessage());
	 	   }
	 	   return conn;

	    }

	private static Connection  getConnection1() throws ClassNotFoundException, SQLException
    {
		 Class.forName("com.ibm.db2.jcc.DB2Driver");                       
         System.out.println("**** Loaded the DB2 JDBC driver");
        String serverName ="bluemix05.bluforcloud.com";
         String portNumber="50000";
         String databaseName="BLUDB";
        String userName="dash017728";
        String password ="2gwXRe7rWdtV";
        String URL="jdbc:db2://bluemix05.bluforcloud.com:50000/BLUDB";
       Connection  connection =
               DriverManager.getConnection("jdbc:db2://"+serverName+":"+portNumber+"/"+databaseName+","+userName+","+password);

       System. out .println( "DB2 Connection SUccessful>>>>>>" );
       return connection;
    }
	


		@POST
		@Produces("application/json")
		@Path("/{SAFETYLOCATION_EUCLEDEAN}")
		@OAuthSecurity(enabled = false)
	public Response SAFETYLOCATION_EUCLEDEAN(@FormParam("LATITUDE") String LATITUDE,
								@FormParam("LONGITUDE") String LONGITUDE,
								@FormParam("MOBILENO") String MOBILENO,
								@FormParam("APPID") String APPID)
										throws SQLException{

		Connection con = null;
		Statement getUser =null;
		ResultSet rs=null;
	
			con = getConnection();
		
		String sql = " SELECT Terminus_ID,(((latitude - "+LATITUDE+")**2 + (longitude - "+LONGITUDE+")**2)** 0.5 )    ";
		sql =sql + "   as EUCLEDIAN_DISTANCE       ";
		sql =sql + "   , latitude, longitude,"+LATITUDE+"  as mylat ,"+LONGITUDE+"  as mylong  , TERMINUS_NAME AS SAFETY_LOCATION_name   ";
		sql =sql + "   from  TBL_SAFETYLOCATION    ";
		sql =sql + "   order by 2 ASC   ";
		sql =sql + "   fetch first  5 rows  only  ";
		
		System.out.println("SQL:::::"+sql);
		
		getUser = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        System.out.println("SQL::::"+sql.toString());
        ResultSet data  = (ResultSet)getUser.executeQuery(sql.toString());


		try{
			JSONObject result = new JSONObject();
			if(data.first()){
				result.put("SAFETY_LOCATION_ID", data.getString("Terminus_ID"));
				result.put("EUCLEDIAN_DISTANCE", data.getString("EUCLEDIAN_DISTANCE"));
				result.put("SAFETY_LOCATION_LATITUDE", data.getString("latitude"));
				result.put("SAFETY_LOCATION_LONGITUDE", data.getString("longitude"));
				result.put("SAFETY_LOCATION_NAME", data.getString("SAFETY_LOCATION_name"));
				
				result.put("CURRENT_LOCATION_LATITUDE", data.getString("mylat"));
				result.put("CURRENT_LOCATION_LONGITUDE", data.getString("mylong"));
				return Response.ok(result).build();

			} else{
				return Response.status(Status.NOT_FOUND).entity("User not found...").build();
			}

		} 
		finally{
			//Close resources in all cases
			con.close();
			getUser.close();
		}

	}

		
		

		@POST
		@Produces("application/json")
		@Path("/{SAFETYLOCATION_MANHATTAN}")
		@OAuthSecurity(enabled = false)
	public Response SAFETYLOCATION_MANHATTAN(@FormParam("LATITUDE") String LATITUDE,
								@FormParam("LONGITUDE") String LONGITUDE,
								@FormParam("MOBILENO") String MOBILENO,
								@FormParam("APPID") String APPID)
										throws SQLException{

		Connection con = null;
		Statement getUser =null;
		ResultSet rs=null;
	
			con = getConnection();
		

			String sql = " SELECT Terminus_ID,((latitude - "+LATITUDE+")**2)** 0.5 + ((longitude - "+LONGITUDE+")**2 )** 0.5    ";
			sql =sql + "   as MANHATTAN_DISTANCE       ";
			sql =sql + "   , latitude, longitude,"+LATITUDE+"  as mylat ,"+LONGITUDE+"  as mylong  , TERMINUS_NAME AS SAFETY_LOCATION_name   ";
			sql =sql + "   from  TBL_SAFETYLOCATION    ";
			sql =sql + "   order by 2 ASC   ";
			sql =sql + "   fetch first  5 rows  only  ";
			
		
		System.out.println("SQL:::::"+sql);
		
		getUser = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        System.out.println("SQL::::"+sql.toString());
        ResultSet data  = (ResultSet)getUser.executeQuery(sql.toString());


		try{
			JSONObject result = new JSONObject();
			if(data.first()){
				result.put("SAFETY_LOCATION_ID", data.getString("Terminus_ID"));
				result.put("EUCLEDIAN_DISTANCE", data.getString("MANHATTAN_DISTANCE"));
				result.put("SAFETY_LOCATION_LATITUDE", data.getString("latitude"));
				result.put("SAFETY_LOCATION_LONGITUDE", data.getString("longitude"));
				result.put("SAFETY_LOCATION_NAME", data.getString("SAFETY_LOCATION_name"));
				
				result.put("CURRENT_LOCATION_LATITUDE", data.getString("mylat"));
				result.put("CURRENT_LOCATION_LONGITUDE", data.getString("mylong"));
				return Response.ok(result).build();

			} else{
				return Response.status(Status.NOT_FOUND).entity("User not found...").build();
			}

		} 
		finally{
			//Close resources in all cases
			con.close();
			getUser.close();
		}

	}

		
	
		
}
