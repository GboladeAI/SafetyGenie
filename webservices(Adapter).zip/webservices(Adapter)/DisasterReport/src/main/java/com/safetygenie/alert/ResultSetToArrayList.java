package com.safetygenie.alert;

/*
*Author 		:Shada A Taiwo
*Directorate	        :Information Technology
*Department		:Business System Development
*Unit			:Research & Development
*Date Created	        :16th of September, 2004
 *
*
*
*/

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;



public class ResultSetToArrayList
{
public ArrayList < String > columnHeaders;
public ArrayList < ArrayList > tableData;
public ArrayList < String > rowData;
public int RowCount=0;


public  ArrayList ResultSetToArrayList( final ResultSet rset)
throws SQLException {

ResultSetMetaData rsResultSet = (ResultSetMetaData) rset.getMetaData();
int count = rsResultSet.getColumnCount();
columnHeaders = new ArrayList ();
tableData = new  ArrayList();

/*for (int i= 1; i<= count ; i++)
{
columnHeaders.add(rsResultSet.getColumnName(i));
}
*/
//rset.beforeFirst();
while (rset.next())
{//begin while
rowData = new ArrayList();
for (int i=1; i<=count; i++)
{
 if (rset.getObject(i)==null)
 {
     rowData.add(" ");
 }
 else
 {
rowData.add(rset.getObject(i).toString());
}
}
tableData.add(rowData);
rowData=null; /// set rowData ArrayList to null after the addition to tableData ArrayList
RowCount=RowCount+1;
}// end while
return tableData;
}





public   ArrayList ColumnNames(ResultSet rset) throws SQLException {
ResultSetMetaData rsResultSet = (ResultSetMetaData) rset.getMetaData();
int count = rsResultSet.getColumnCount();
columnHeaders = new ArrayList < String >(count);
tableData = new  ArrayList < ArrayList >();

for (int i= 1; i<= count ; i++)
{
columnHeaders.add(rsResultSet.getColumnName(i));
}
return columnHeaders;
}

public int getColumnCount()
{
return columnHeaders.size();
}

public int getRowCount()
{
return tableData.size();
}

}



